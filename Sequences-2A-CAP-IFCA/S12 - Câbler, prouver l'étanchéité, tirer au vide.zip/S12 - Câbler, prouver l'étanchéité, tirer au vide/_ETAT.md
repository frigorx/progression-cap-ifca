# État de la séquence S12 — Câbler, prouver l'étanchéité, tirer au vide

*Convention de rangement (usine FrigorX) : un dossier par séquence ; à la racine le **Dossier de
séquence** (plan de séquence + plans de séance intégrés) ; un sous-dossier par séance :
Plan de séance · Document élève · Document professeur.*

## ✅ SÉQUENCE COMPLÈTE (03/07/2026) — 10 documents, harmonisés échelle 0-4

- [x] **Dossier de séquence S12.html** — page de garde, plan de séquence, 3 plans de séance intégrés
- [x] **Séance 1** : Plan de séance (fiche 10 phases) · Document élève (TP câblage) · Document professeur
- [x] **Séance 2** : Plan de séance · Document élève (TP pressostats, plan de travail à jalons, méthode
      signature 5 étapes) · Document professeur
- [x] **Séance 3** : Plan de séance · Document élève (situation-problème étanchéité/vide) · Document
      professeur (+ sujets des 3 postes de l'évaluation sommative)
- [x] Présélection bibliothèque (03/07) → `..\BIBLIOTHEQUE.md` rubrique S12 — sources utilisées et citées
- [x] Contrôle qualité + harmonisation **échelle 0-4** (3 agents, 03/07) : grilles 5 cases à critères
      observables, niveau 4 rédigé par compétence, minutages 4 h + 4 h vérifiés, sécurité azote complète
- [x] **Enrichissement pédagogique (03/07, retour Franck « l'âme »)** : images RÉELLES extraites des docx
      sources et intégrées (`images\` : schéma CCF complet, schéma fluidique manifold+pompe à vide,
      exercices manomètres, pompe légendée) ; schéma DANS chaque TP avec consignes référencées aux repères ;
      **cadres de dessin** (10 côté élève) avec consigne dans le cadre ; zones de réponse calibrées, unités
      pré-imprimées ; activité surlignage rouge/bleu ; axes SVG pour la courbe de pression ; chemins
      d'images vérifiés ✓. Corrigés ancrés sur les images (b1 : x11-x12, b2 : x12-x14), zéro invention
      (repères pompe 1-12 « à compléter par le professeur » — la source ne donne pas la correspondance)

## En attente de Franck (bloque la version « définitive », pas l'utilisation)
- PNG officiels des logos (EQUATIO + sigle lycée) — les documents portent la reconstitution vectorielle
- Libellé du savoir **S2.4** (absent du référentiel structuré)
- Orthographe de la formule (« Bauer / Bowers » ?)
- Texte définitif du pseudo-copyright
- Choix de forme : auto-positionnement élève en pointillés ou en cases à cocher 0-4 (séance 3, feuille 5)
- **Validation pédagogique d'ensemble sur pièce** (relire, annoter, on itère)
